export const services = [  
    "Consulting Services",
    "Products and Solutions",
    "Corproate Training",
    "Talent Management",
    "Information Technology"
]